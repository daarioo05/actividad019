package com.empresa.demo;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import java.util.Arrays;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class HelloController {
    @FXML
    private Label statusLabel;

    // Declaración de variables para la conexión a MongoDB
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;

    // Constructor de la clase
    public HelloController() {
        // Inicialización de la conexión a MongoDB Atlas
        mongoClient = MongoClients.create("mongodb+srv://<username>:<password>@cluster0.mongodb.net/");
        database = mongoClient.getDatabase("test");
        collection = database.getCollection("test");

        // Operaciones CRUD
        Document doc = new Document("name", "MongoDB")
                .append("type", "database")
                .append("count", 1)
                .append("versions", Arrays.asList("v3.2", "v3.0", "v2.6"))
                .append("info", new Document("x", 203).append("y", 102));
        collection.insertOne(doc);

        // Implementación de QuickSort
        int[] arr = {10, 7, 8, 9, 1, 5};
        int n = arr.length;
        Arrays.sort(arr);

        // Implementación de Binary Search
        int result = Arrays.binarySearch(arr, 10);

        // Medición del tiempo de ejecución
        long startTime = System.nanoTime();
        // código a medir
        long endTime = System.nanoTime();
        long duration = (endTime - startTime);

        // Actualización del texto del Label
        statusLabel.setText("Operaciones completadas. Tiempo de ejecución: " + duration + " nanosegundos");
    }
}
