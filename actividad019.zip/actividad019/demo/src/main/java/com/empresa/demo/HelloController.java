package com.empresa.demo;

import com.mongodb.ConnectionString;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import java.util.Date;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.set;

public class HelloController {
    @FXML
    private TextField productNameField;

    @FXML
    private TextField productPriceField;

    @FXML
    private TableView<Product> productTable;

    @FXML
    private TableColumn<Product, String> productNameColumn;

    @FXML
    private TableColumn<Product, Double> productPriceColumn;

    // Declaración de variables para la conexión a MongoDB
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;

    // Constructor de la clase
    public HelloController() {
        // Inicialización de la conexión a MongoDB Atlas
        mongoClient = MongoClients.create(new ConnectionString("mongodb+srv://lector:lector@cluster0.mongodb.net"));
        database = mongoClient.getDatabase("test");
        collection = database.getCollection("products");

        // Configuración de la tabla
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        // Cargar productos en la tabla
        loadProducts();
    }

    // Método para agregar un nuevo producto
    @FXML
    private void handleAddProductButton() {
        String name = productNameField.getText();
        double price = Double.parseDouble(productPriceField.getText());
        Product product = new Product(name, price);
        createProduct(product);
        loadProducts(); // Recargar la tabla
        productNameField.clear();
        productPriceField.clear();
    }

    // Método para cargar productos en la tabla
    private void loadProducts() {
        ObservableList<Product> products = FXCollections.observableArrayList();
        collection.find().forEach(document -> {
            String name = document.getString("name");
            double price = document.getDouble("price");
            products.add(new Product(name, price));
        });
        productTable.setItems(products);
    }

    // Método para crear un nuevo producto en la base de datos
    private void createProduct(Product product) {
        Document doc = new Document("name", product.getName())
                .append("price", product.getPrice())
                .append("createdAt", new Date());
        collection.insertOne(doc);
    }

    // Clase de modelo para los productos
    public static class Product {
        private String name;
        private double price;

        public Product(String name, double price) {
            this.name = name;
            this.price = price;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }
    }
}
